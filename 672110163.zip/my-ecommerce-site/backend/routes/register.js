const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');
const users = require('../data/user.json');  
const userFilePath = path.join(__dirname, '../data/user.json');

router.post('/', (req, res) => {
  try {
    const { fname, lname, occupation_category, occupation, email, password } = req.body;
    if(users.find(user => user.Email === email)){
       return res.status(200).json({status:"This email is already been used."})
    }
    const newUser = {
      Firstname: fname,
      Lastname: lname,
      Ocupation_Category: occupation_category,
      Occupation: occupation,
      Email: email,
      Password: password
    };

    const fileData = fs.readFileSync(userFilePath, 'utf-8');
    const userData = fileData.trim() === '' ? [] : JSON.parse(fileData);

    userData.push(newUser);
    fs.writeFileSync(userFilePath, JSON.stringify(userData, null, 2));

    res.send("Register successfully");
  } catch (error) {
    console.error("Server Error:", error.message);
    res.status(500).send("Internal Server Error");
  }
});

module.exports = router;
